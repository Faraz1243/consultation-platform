import React, { Component } from 'react'

export class TinyFooter extends Component {
  render() {
    return (
        <>
            {/* Footer */}
            <div className="footer-copyright  bg-transparent">
                <div className="container">
                <div className="row">
                    <div className="col-md-12">
                    <p>Copyright © 2024. All Rights Reserved Konsult</p>
                    </div>
                </div>
                </div>
            </div>
            {/* /Footer */}
      </>
      
    )
  }
}

export default TinyFooter
