import React, { Component } from 'react'
import { Link, NavLink } from 'react-router-dom'

export class SidePane extends Component {
  render() {
    return (
        <>
      {/* Side Pane */}
      <div className="col-xl-3 col-lg-4 theiaStickySidebar">
        <div className="card user-sidebar mb-4 mb-lg-0">

          <div className="card-header user-sidebar-header mb-4">
            <div className="d-flex justify-content-center align-items-center flex-column">
              <span className="user rounded-circle avatar avatar-xxl mb-2">
                <img
                  src="assets/img/profiles/avatar-21.jpg"
                  className="img-fluid rounded-circle"
                  alt="Img"
                />
              </span>
              <h6 className="mb-2">John Smith</h6>
              <p className="fs-14">Member Since Sep 2021</p>
            </div>
          </div>

          <div className="card-body user-sidebar-body p-0">
            <ul>
              <li className="mb-4">
                <NavLink
                  to="/user/dashboard"
                  className={({ isActive }) => 
                    isActive ? "d-flex align-items-center active" : "d-flex align-items-center"
                  }
                >
                  <i className="ti ti-layout-grid me-2" />
                  Dashboard
                </NavLink>
              </li>
              <li className="mb-4">
                <NavLink
                  to="/user/bookings"
                  className={({ isActive }) => 
                    isActive ? "d-flex align-items-center active" : "d-flex align-items-center"
                  }
                >
                  <i className="ti ti-device-mobile me-2" />
                  Bookings
                </NavLink>
              </li>
              <li className="mb-4">
                <NavLink to="/user/favourites" 
                  className={({ isActive }) => 
                    isActive ? "d-flex align-items-center active" : "d-flex align-items-center"
                  }
                >
                  <i className="ti ti-heart me-2" />
                  Favorites
                </NavLink>
              </li>
              <li className="mb-4">
                <NavLink
                  to="customer-reviews.html"
                  className={({ isActive }) => 
                    isActive ? "d-flex align-items-center active" : "d-flex align-items-center"
                  }
                >
                  <i className="ti ti-star me-2" />
                  Reviews
                </NavLink>
              </li>
              <li className="mb-4">
                <a href="user-chat.html" className="d-flex align-items-center">
                  <i className="ti ti-message-circle me-2" />
                  Chat
                </a>
              </li>
              <li className="submenu">
                <a href="#" className="d-block mb-3">
                  <i className="ti ti-settings me-2" />
                  <span>Settings</span>
                  <span className="menu-arrow" />
                </a>
                <ul className="ms-4">
                  <li className="mb-3">
                    <a
                      href="account-settings.html"
                      className="fs-14 d-inline-flex align-items-center"
                    >
                      <i className="ti ti-chevrons-right me-2" />
                      Account Settings
                    </a>
                  </li>
                  <li className="mb-3">
                    <a
                      href="security-settings.html"
                      className="fs-14 d-inline-flex align-items-center"
                    >
                      <i className="ti ti-chevrons-right me-2" />
                      Security Settings
                    </a>
                  </li>
                  <li className="mb-3">
                    <a
                      href="notification-settings.html"
                      className="fs-14 d-inline-flex align-items-center"
                    >
                      <i className="ti ti-chevrons-right me-2" />
                      Notifications
                    </a>
                  </li>
                  <li className="mb-3">
                    <a
                      href="connected-apps.html"
                      className="fs-14 d-inline-flex align-items-center"
                    >
                      <i className="ti ti-chevrons-right me-2" />
                      Connected Apps
                    </a>
                  </li>
                  <li className="mb-3">
                    <a
                      href="javascript:void(0);"
                      data-bs-toggle="modal"
                      data-bs-target="#del-account"
                      className="fs-14"
                    >
                      <i className="ti ti-chevrons-right me-2" />
                      Delete Account
                    </a>
                  </li>
                </ul>
              </li>
              <li className="mb-0">
                <a href="login.html" className="d-flex align-items-center">
                  <i className="ti ti-logout me-2" />
                  Logout
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </>
    
      );
  }
}

export default SidePane
