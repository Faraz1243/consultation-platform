import React, { Component } from 'react'
import { Navbar } from 'react-bootstrap'
import SidePane from './sidePane'
import Footer from '../../components/footer'

export class UserFavourites extends Component {
  render() {
    return (
      <div>
        <Navbar />
        <div className="page-wrapper">
          <div className="content">
            <div className="container">
              <div className="row justify-content-center">
              <SidePane/>
              <MainContent/>

              </div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    )
  }
}

export default UserFavourites

const MainContent = ()=>{
  return (
    <>
    <div className="col-xl-9 col-lg-8">
    </div>
    </>
  );
}