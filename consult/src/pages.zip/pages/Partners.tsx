import React, { Component } from 'react'
import NavBar from '../components/navbar'
import Footer from '../components/footer'

export class Partners extends Component {
  render() {
    return (
      <div>
        <NavBar />
        Partners        
        <Footer/>
      </div>
    )
  }
}

export default Partners
